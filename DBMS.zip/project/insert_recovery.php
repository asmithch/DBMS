<?php
include 'db_connection.php';

// Retrieve values from the form
$Recovery_id = isset($_POST['Recovery_id']) ? mysqli_real_escape_string($conn, $_POST['Recovery_id']) : '';
$conditionofproperty = isset($_POST['conditionofproperty']) ? mysqli_real_escape_string($conn, $_POST['conditionofproperty']) : ''; // Updated the variable name
$time_taken = isset($_POST['time_taken']) ? mysqli_real_escape_string($conn, $_POST['time_taken']) : '';
$datetime = isset($_POST['date']) ? mysqli_real_escape_string($conn, $_POST['date']) : '';
$Property_id = isset($_POST['Property_id']) ? mysqli_real_escape_string($conn, $_POST['Property_id']) : '';
$Theft_id = isset($_POST['Theft_id']) ? mysqli_real_escape_string($conn, $_POST['Theft_id']) : '';

// Create and execute SQL INSERT statement for 'recovery' table
$sql_recovery = "INSERT INTO recovery (Recovery_id, conditionofproperty, time_taken, datetime, Property_id, Theft_id) VALUES (?, ?, ?, ?, ?, ?)";
$stmt_recovery = mysqli_prepare($conn, $sql_recovery);

if (!$stmt_recovery) {
    die('Error in preparing the statement: ' . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_recovery, 'ssssss', $Recovery_id, $conditionofproperty, $time_taken, $datetime, $Property_id, $Theft_id);
mysqli_stmt_execute($stmt_recovery);

if (mysqli_stmt_errno($stmt_recovery) == 1062) {
    // Duplicate key error, handle it as needed
    echo "Recovery with the same ID already exists.";
}

mysqli_stmt_close($stmt_recovery);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location: recovery_form.html");
exit();
?>