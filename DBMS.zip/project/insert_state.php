<?php
include 'db_connection.php';

// Retrieve values from the form
$State_name = isset($_POST['State_name']) ? mysqli_real_escape_string($conn, $_POST['State_name']) : '';
$Number_of_thefts = isset($_POST['Number_of_thefts']) ? mysqli_real_escape_string($conn, $_POST['Number_of_thefts']) : '';
$recovery_rate = isset($_POST['recovery_rate']) ? mysqli_real_escape_string($conn, $_POST['recovery_rate']) : '';
$theft_rate = isset($_POST['theft_rate']) ? mysqli_real_escape_string($conn, $_POST['theft_rate']) : '';
$number_of_policestations = isset($_POST['number_of_policestations']) ? mysqli_real_escape_string($conn, $_POST['number_of_policestations']) : '';
$number_of_properties = isset($_POST['number_of_properties']) ? mysqli_real_escape_string($conn, $_POST['number_of_properties']) : '';

// Create and execute SQL INSERT statement for 'state' table
$sql = "INSERT INTO state (State_name, Number_of_thefts, recovery_rate, theft_rate, number_of_policestations, number_of_properties) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'siiiii', $State_name, $Number_of_thefts, $recovery_rate, $theft_rate, $number_of_policestations, $number_of_properties);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_errno($stmt) == 1062) {
    // Duplicate key error, handle it as needed
    echo "State with the same name already exists.";
}

mysqli_stmt_close($stmt);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location: state_form.html");
exit();
?>
