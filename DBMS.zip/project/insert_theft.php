<?php
include 'db_connection.php';

// Retrieve values from the form
$Theft_id = isset($_POST['Theft_id']) ? mysqli_real_escape_string($conn, $_POST['Theft_id']) : '';
$state_name = isset($_POST['state_name']) ? mysqli_real_escape_string($conn, $_POST['state_name']) : '';
$date = isset($_POST['date']) ? mysqli_real_escape_string($conn, $_POST['date']) : '';
$location = isset($_POST['location']) ? mysqli_real_escape_string($conn, $_POST['location']) : '';
$state = isset($_POST['state']) ? mysqli_real_escape_string($conn, $_POST['state']) : '';
$property_id = isset($_POST['property_id']) ? mysqli_real_escape_string($conn, $_POST['property_id']) : '';

// Create and execute SQL INSERT statement for 'theft' table
$sql_theft = "INSERT INTO theft (Theft_id, state_name, date, location, state, property_id) VALUES (?, ?, ?, ?, ?, ?)";
$stmt_theft = mysqli_prepare($conn, $sql_theft);
mysqli_stmt_bind_param($stmt_theft, 'ssssss', $Theft_id, $state_name, $date, $location, $state, $property_id);
mysqli_stmt_execute($stmt_theft);

if (mysqli_stmt_errno($stmt_theft) == 1062) {
    // Duplicate key error, handle it as needed
    echo "Theft with the same ID already exists.";
}

mysqli_stmt_close($stmt_theft);

// Create and execute SQL INSERT statement for 'prop' table
$sql_prop = "INSERT INTO prop (State_name, Property_id) VALUES (?, ?)";
$stmt_prop = mysqli_prepare($conn, $sql_prop);
mysqli_stmt_bind_param($stmt_prop, 'ss', $state_name, $property_id);
mysqli_stmt_execute($stmt_prop);

if (mysqli_stmt_errno($stmt_prop) == 1062) {
    // Duplicate key error, handle it as needed
    echo "Data with the same State_name and Property_id already exists in the prop table.";
}

mysqli_stmt_close($stmt_prop);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location: theft_form.html");
exit();
?>
