<?php
include 'db_connection.php';

// Retrieve values from the form
$owner_id = isset($_POST['owner_id']) ? mysqli_real_escape_string($conn, $_POST['owner_id']) : '';
$owner_name = isset($_POST['owner_name']) ? mysqli_real_escape_string($conn, $_POST['owner_name']) : '';

// Create and execute SQL UPDATE statement for 'owner' table
$sql_update_owner = "UPDATE owner SET owner_name = ? WHERE owner_id = ?";
$stmt_update_owner = mysqli_prepare($conn, $sql_update_owner);

if (!$stmt_update_owner) {
    die('Error in preparing the statement: ' . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_update_owner, 'ss', $owner_name, $owner_id);
mysqli_stmt_execute($stmt_update_owner);

mysqli_stmt_close($stmt_update_owner);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location:update_form.html");
exit();
?>