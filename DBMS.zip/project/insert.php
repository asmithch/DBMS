<?php
include 'db_connection.php';

// Retrieve values from the form
$owner_name = isset($_POST['owner_name']) ? mysqli_real_escape_string($conn, $_POST['owner_name']) : '';
$Dateofbirth = isset($_POST['Dateofbirth']) ? mysqli_real_escape_string($conn, $_POST['Dateofbirth']) : '';

$number_of_properties = isset($_POST['number_of_properties']) ? mysqli_real_escape_string($conn, $_POST['number_of_properties']) : '';
$state = isset($_POST['state']) ? mysqli_real_escape_string($conn, $_POST['state']) : '';
$city = isset($_POST['city']) ? mysqli_real_escape_string($conn, $_POST['city']) : '';

// Use the new form element name
$number_of_familymembers = isset($_POST['number_of_familymembers']) ? mysqli_real_escape_string($conn, $_POST['number_of_familymembers']) : '';

$age = isset($_POST['age']) ? mysqli_real_escape_string($conn, $_POST['age']) : '';

$address = isset($_POST['address']) ? mysqli_real_escape_string($conn, $_POST['address']) : '';
$type = isset($_POST['type']) ? mysqli_real_escape_string($conn, $_POST['type']) : '';
$value = isset($_POST['value']) ? mysqli_real_escape_string($conn, $_POST['value']) : '';
$owner_id = isset($_POST['owner_id']) ? mysqli_real_escape_string($conn, $_POST['owner_id']) : '';
$phone_number = isset($_POST['phone_number']) ? mysqli_real_escape_string($conn, $_POST['phone_number']) : '';
$property_id = isset($_POST['property_id']) ? mysqli_real_escape_string($conn, $_POST['property_id']) : '';

// Check if owner_id already exists
$check_owner_sql = "SELECT owner_id FROM owner WHERE owner_id = ?";
$check_owner_stmt = mysqli_prepare($conn, $check_owner_sql);
mysqli_stmt_bind_param($check_owner_stmt, 'i', $owner_id);
mysqli_stmt_execute($check_owner_stmt);
mysqli_stmt_store_result($check_owner_stmt);

if (mysqli_stmt_num_rows($check_owner_stmt) == 0) {
    // If owner_id doesn't exist, insert it into 'owner' table
    $insert_owner_sql = "INSERT INTO owner (owner_id, owner_name, Dateofbirth, number_of_properties, state, city, number_of_familymembers, age) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $insert_owner_stmt = mysqli_prepare($conn, $insert_owner_sql);
    mysqli_stmt_bind_param($insert_owner_stmt, 'isissisi', $owner_id, $owner_name, $Dateofbirth, $number_of_properties, $state, $city, $number_of_familymembers, $age);
    mysqli_stmt_execute($insert_owner_stmt);
    mysqli_stmt_close($insert_owner_stmt);
}

mysqli_stmt_close($check_owner_stmt);

// Insert phone_number into 'phone' table if it doesn't exist
$check_phone_sql = "SELECT owner_id FROM phone WHERE owner_id = ?";
$check_phone_stmt = mysqli_prepare($conn, $check_phone_sql);
mysqli_stmt_bind_param($check_phone_stmt, 'i', $owner_id);
mysqli_stmt_execute($check_phone_stmt);
mysqli_stmt_store_result($check_phone_stmt);

if (mysqli_stmt_num_rows($check_phone_stmt) == 0) {
    $insert_phone_sql = "INSERT INTO phone (owner_id, phone_number) VALUES (?, ?)";
    $insert_phone_stmt = mysqli_prepare($conn, $insert_phone_sql);
    mysqli_stmt_bind_param($insert_phone_stmt, 'is', $owner_id, $phone_number);
    mysqli_stmt_execute($insert_phone_stmt);
    mysqli_stmt_close($insert_phone_stmt);
}

mysqli_stmt_close($check_phone_stmt);

// Create and execute SQL INSERT statement for 'property' table
$sql = "INSERT INTO property (address, type, value, owner_id, property_id) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'ssiii', $address, $type, $value, $owner_id, $property_id);
mysqli_stmt_execute($stmt);

if (mysqli_stmt_errno($stmt) == 1062) {
    // Duplicate key error, property_id already exists
    // Handle the case appropriately (e.g., redirect with an error message)
    echo "Property with ID $property_id already exists.";
}

mysqli_stmt_close($stmt);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location: index.html");
exit();
?>
