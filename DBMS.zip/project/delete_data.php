<?php
include 'db_connection.php';

// Retrieve Property ID from the form
$property_id_to_delete = isset($_POST['property_id']) ? mysqli_real_escape_string($conn, $_POST['property_id']) : '';

// Delete rows from 'prop' table
$delete_prop_sql = "DELETE FROM prop WHERE property_id = ?";
$delete_prop_stmt = mysqli_prepare($conn, $delete_prop_sql);
mysqli_stmt_bind_param($delete_prop_stmt, 'i', $property_id_to_delete);
mysqli_stmt_execute($delete_prop_stmt);
mysqli_stmt_close($delete_prop_stmt);

// Delete rows from 'recovery' table
$delete_recovery_sql = "DELETE FROM recovery WHERE property_id = ?";
$delete_recovery_stmt = mysqli_prepare($conn, $delete_recovery_sql);
mysqli_stmt_bind_param($delete_recovery_stmt, 'i', $property_id_to_delete);
mysqli_stmt_execute($delete_recovery_stmt);
mysqli_stmt_close($delete_recovery_stmt);

// Delete rows from 'theft' table
$delete_theft_sql = "DELETE FROM theft WHERE property_id = ?";
$delete_theft_stmt = mysqli_prepare($conn, $delete_theft_sql);
mysqli_stmt_bind_param($delete_theft_stmt, 'i', $property_id_to_delete);
mysqli_stmt_execute($delete_theft_stmt);
mysqli_stmt_close($delete_theft_stmt);

// Delete rows from 'property' table
$delete_property_sql = "DELETE FROM property WHERE property_id = ?";
$delete_property_stmt = mysqli_prepare($conn, $delete_property_sql);
mysqli_stmt_bind_param($delete_property_stmt, 'i', $property_id_to_delete);
mysqli_stmt_execute($delete_property_stmt);
mysqli_stmt_close($delete_property_stmt);

// Close MySQL connection
mysqli_close($conn);

// Redirect to the form page or display a success message
header("Location: delete_form.html");
exit();
?>
